// Runs in the customer's browser.
// (1) fetches the menu + your WhatsApp number from the server
// (2) tracks the cart in a plain JS object (cart line key = "productId::variantId")
// (3) builds a pre-filled WhatsApp message and opens it - no data is sent
//     to our own server for the order itself.

let products = [];
let whatsappNumber = '';
let activeCategory = 'All';
const cart = {}; // { "productId::variantId": { productId, variantId, qty } }

const productGrid = document.getElementById('productGrid');
const signatureGrid = document.getElementById('signatureGrid');
const cartDrawer = document.getElementById('cartDrawer');
const cartOverlay = document.getElementById('cartOverlay');
const cartItemsEl = document.getElementById('cartItems');
const cartTotalEl = document.getElementById('cartTotal');
const cartCountEl = document.getElementById('cartCount');
const whatsappBtn = document.getElementById('whatsappBtn');
const brandLogoEl = document.getElementById('brandLogo');
const floatingWhatsapp = document.getElementById('floatingWhatsapp');
const navToggle = document.getElementById('navToggle');
const siteNav = document.getElementById('siteNav');

function formatPrice(cents) {
  const rupees = Math.round(cents / 100);
  return `₹${rupees.toLocaleString('en-IN')}`;
}

function escapeHtml(str) {
  const div = document.createElement('div');
  div.textContent = str == null ? '' : str;
  return div.innerHTML;
}

// A product with variants has no single price - use the lowest variant price as the "from" price
function displayPrice(product) {
  if (product.variants && product.variants.length > 0) {
    const min = Math.min(...product.variants.map(v => v.price_cents));
    return `From ${formatPrice(min)}`;
  }
  return formatPrice(product.price_cents);
}

// ---- Load page in for the current messages (story, contact, testimonials) ----
async function loadContent() {
  try {
    const res = await fetch('/api/content');
    const c = await res.json();

    const storyEl = document.getElementById('storyText');
    if (storyEl && c.story_text) {
      storyEl.textContent = c.story_text;
    }

    const addressEl = document.getElementById('contactAddress');
    if (addressEl && c.contact_address) {
      addressEl.textContent = c.contact_address;
      addressEl.classList.remove('placeholder-note');
    }
    const phoneEl = document.getElementById('contactPhone');
    if (phoneEl && c.contact_phone) {
      phoneEl.textContent = c.contact_phone;
      phoneEl.classList.remove('placeholder-note');
    }

    document.querySelectorAll('.testimonial-card').forEach(card => {
      const slot = card.dataset.slot;
      const quote = c[`testimonial_${slot}_quote`];
      const name = c[`testimonial_${slot}_name`];
      if (quote) card.querySelector('[data-field="quote"]').textContent = `"${quote}"`;
      if (name) card.querySelector('[data-field="name"]').textContent = `— ${name}`;
    });
  } catch (err) {
    // ignore - placeholders just stay as-is
  }
}

// ---- Load menu + config ----
async function init() {
  try {
    const [productsRes, configRes] = await Promise.all([
      fetch('/api/products'),
      fetch('/api/config')
    ]);
    products = await productsRes.json();
    const config = await configRes.json();
    whatsappNumber = config.whatsappNumber;

    if (config.logoUrl && brandLogoEl) {
      brandLogoEl.innerHTML = `<img src="${config.logoUrl}" alt="Happy Treats logo">`;
    }
    if (whatsappNumber && floatingWhatsapp) {
      floatingWhatsapp.href = `https://wa.me/${whatsappNumber}?text=${encodeURIComponent("Hi! I'd like to know more about Happy Treats' cakes.")}`;
      floatingWhatsapp.style.display = 'flex';
    }

    renderProducts();
    renderSignature();
    loadContent();
  } catch (err) {
    productGrid.innerHTML = '<p class="loading">Could not load the menu. Is the server running?</p>';
  }
}

function productCardHtml(p) {
  const hasVariants = p.variants && p.variants.length > 0;
  return `
    <div class="product-card">
      <div class="product-image-wrap">
        ${p.image_url
          ? `<img class="product-image" src="${p.image_url}" alt="${escapeHtml(p.name)}">`
          : `<div class="product-image-placeholder">${escapeHtml(p.name.charAt(0))}</div>`
        }
        <span class="product-tag">${escapeHtml(p.category)}</span>
      </div>
      <div class="product-body">
        <div class="product-name">${escapeHtml(p.name)}</div>
        <div class="product-desc">${escapeHtml(p.description || '')}</div>
        ${p.customization_note ? `<div class="product-customization">✏️ ${escapeHtml(p.customization_note)}</div>` : ''}
        ${hasVariants ? `
          <label class="variant-select-label">Choose weight/option</label>
          <select class="variant-select" data-id="${p.id}">
            ${p.variants.map(v => `<option value="${v.id}">${escapeHtml(v.label)} — ${formatPrice(v.price_cents)}</option>`).join('')}
          </select>
        ` : ''}
        <div class="product-footer">
          <span class="product-price">${displayPrice(p)}</span>
          <button class="add-btn" data-id="${p.id}">Add</button>
        </div>
        <button class="customize-btn" data-id="${p.id}">Want it customized? Ask on WhatsApp</button>
      </div>
    </div>
  `;
}

function renderProducts() {
  const visible = activeCategory === 'All' ? products : products.filter(p => p.category === activeCategory);

  if (visible.length === 0) {
    productGrid.innerHTML = '<p class="loading">No items in this category yet.</p>';
    return;
  }

  productGrid.innerHTML = visible.map(productCardHtml).join('');
  wireProductCardEvents(productGrid);
}

function renderSignature() {
  if (!signatureGrid) return;
  const signature = products.filter(p => p.is_signature);
  if (signature.length === 0) {
    signatureGrid.closest('.signature-section')?.setAttribute('hidden', 'true');
    return;
  }
  signatureGrid.innerHTML = signature.map(productCardHtml).join('');
  wireProductCardEvents(signatureGrid);
}

function wireProductCardEvents(container) {
  container.querySelectorAll('.add-btn').forEach(btn => {
    btn.addEventListener('click', () => addToCart(parseInt(btn.dataset.id, 10), container));
  });
  container.querySelectorAll('.customize-btn').forEach(btn => {
    btn.addEventListener('click', () => requestCustomization(parseInt(btn.dataset.id, 10)));
  });
}

// ---- Customization request (separate from the fixed-cake cart flow) ----
function requestCustomization(productId) {
  const product = products.find(p => p.id === productId);
  if (!product) return;

  if (!whatsappNumber) {
    alert('The bakery has not set up a WhatsApp number yet. Please contact them directly.');
    return;
  }

  const priceLine = product.variants && product.variants.length > 0
    ? `starting at ${displayPrice(product)}`
    : `base price ${formatPrice(product.price_cents)}`;

  const message = [
    `Hi! I'm interested in the "${product.name}" (${priceLine}), but I'd like to customize it.`,
    product.customization_note ? `I saw the note: ${product.customization_note}` : '',
    `Could we connect to discuss the details and confirm the final price?`
  ].filter(Boolean).join('\n');

  const url = `https://wa.me/${whatsappNumber}?text=${encodeURIComponent(message)}`;
  window.open(url, '_blank');
}

// ---- Cart logic ----
function addToCart(productId, container) {
  const product = products.find(p => p.id === productId);
  if (!product) return;

  let variantId = null;
  if (product.variants && product.variants.length > 0) {
    const select = container.querySelector(`.variant-select[data-id="${productId}"]`);
    variantId = select ? parseInt(select.value, 10) : product.variants[0].id;
  }

  const key = `${productId}::${variantId || 'base'}`;
  if (cart[key]) {
    cart[key].qty += 1;
  } else {
    cart[key] = { productId, variantId, qty: 1 };
  }
  renderCart();
  openCart();
}

function changeQty(key, delta) {
  if (!cart[key]) return;
  cart[key].qty += delta;
  if (cart[key].qty <= 0) delete cart[key];
  renderCart();
}

function lineInfo(entry) {
  const product = products.find(p => p.id === entry.productId);
  if (!product) return null;
  let label = product.name;
  let unitPrice = product.price_cents;
  if (entry.variantId) {
    const variant = (product.variants || []).find(v => v.id === entry.variantId);
    if (variant) {
      label = `${product.name} (${variant.label})`;
      unitPrice = variant.price_cents;
    }
  }
  return { label, unitPrice };
}

function renderCart() {
  const entries = Object.entries(cart);
  const totalCount = entries.reduce((sum, [, e]) => sum + e.qty, 0);
  cartCountEl.textContent = totalCount;
  whatsappBtn.disabled = totalCount === 0;

  if (entries.length === 0) {
    cartItemsEl.innerHTML = '<p class="empty-note">Nothing added yet.</p>';
    cartTotalEl.textContent = formatPrice(0);
    return;
  }

  let total = 0;
  cartItemsEl.innerHTML = entries.map(([key, entry]) => {
    const info = lineInfo(entry);
    if (!info) return '';
    total += info.unitPrice * entry.qty;
    return `
      <div class="cart-line">
        <span class="cart-line-name">${escapeHtml(info.label)}</span>
        <div class="cart-line-controls">
          <button data-key="${key}" data-delta="-1">−</button>
          <span>${entry.qty}</span>
          <button data-key="${key}" data-delta="1">+</button>
        </div>
      </div>
    `;
  }).join('');

  cartTotalEl.textContent = formatPrice(total);

  cartItemsEl.querySelectorAll('button').forEach(btn => {
    btn.addEventListener('click', () => {
      changeQty(btn.dataset.key, parseInt(btn.dataset.delta, 10));
    });
  });
}

// ---- Drawer open/close ----
function openCart() { cartDrawer.classList.add('open'); cartOverlay.hidden = false; }
function closeCart() { cartDrawer.classList.remove('open'); cartOverlay.hidden = true; }
document.getElementById('cartToggle').addEventListener('click', openCart);
document.getElementById('cartClose').addEventListener('click', closeCart);
cartOverlay.addEventListener('click', closeCart);

// ---- Mobile nav toggle ----
if (navToggle && siteNav) {
  navToggle.addEventListener('click', () => siteNav.classList.toggle('open'));
}

// ---- Nav links + homepage category tiles that jump to a specific menu category ----
document.querySelectorAll('.site-nav a[data-cat], .category-tile[data-cat]').forEach(a => {
  a.addEventListener('click', () => {
    activeCategory = a.dataset.cat;
    renderProducts();
    if (siteNav) siteNav.classList.remove('open');
  });
});

// ---- WhatsApp order ----
whatsappBtn.addEventListener('click', () => {
  const entries = Object.entries(cart);
  if (entries.length === 0) return;

  if (!whatsappNumber) {
    alert('The bakery has not set up a WhatsApp number yet. Please contact them directly.');
    return;
  }

  let total = 0;
  const lines = entries.map(([, entry]) => {
    const info = lineInfo(entry);
    if (!info) return '';
    total += info.unitPrice * entry.qty;
    return `• ${entry.qty}x ${info.label} — ${formatPrice(info.unitPrice * entry.qty)}`;
  }).filter(Boolean);

  const message = [
    `Hi! I'd like to check availability and place an order:`,
    ...lines,
    ``,
    `Estimated total: ${formatPrice(total)}`,
    ``,
    `Could we connect to confirm details? I understand this becomes a confirmed order only once we've finalized everything here and I've paid the 50% advance.`
  ].join('\n');

  const url = `https://wa.me/${whatsappNumber}?text=${encodeURIComponent(message)}`;
  window.open(url, '_blank');
});

init();
