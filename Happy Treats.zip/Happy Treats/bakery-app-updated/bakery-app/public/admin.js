// Admin panel logic. The browser sends Basic Auth credentials automatically
// on every fetch() here (that's what the login popup was for).

function formatPrice(cents) {
  const rupees = Math.round(cents / 100);
  return `₹${rupees.toLocaleString('en-IN')}`;
}
function todayStr() {
  return new Date().toISOString().slice(0, 10);
}

// ---- Tabs ----
document.querySelectorAll('.tab-btn').forEach(btn => {
  btn.addEventListener('click', () => {
    document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
    document.querySelectorAll('.tab-panel').forEach(panel => {
      panel.hidden = panel.id !== `${btn.dataset.tab}Tab`;
    });
  });
});

// =========================================================
// DASHBOARD
// =========================================================
let revenueChart = null;

async function loadDashboard() {
  const from = document.getElementById('rangeFrom').value;
  const to = document.getElementById('rangeTo').value;
  const params = new URLSearchParams();
  if (from) params.set('from', from);
  if (to) params.set('to', to);

  const res = await fetch(`/api/admin/dashboard?${params.toString()}`);
  const data = await res.json();

  document.getElementById('statRevenue').textContent = formatPrice(data.revenue_cents);
  document.getElementById('statExpenses').textContent = formatPrice(data.expense_cents);
  document.getElementById('statProfit').textContent = formatPrice(data.profit_cents);
  document.getElementById('statCount').textContent = data.sale_count;

  const topItemsEl = document.getElementById('topItems');
  topItemsEl.innerHTML = data.top_items.length
    ? data.top_items.map(item => `
        <div class="top-item-row">
          <span>${item.product_name} — ${item.total_qty} sold</span>
          <span class="list-row-amount">${formatPrice(item.total_revenue_cents)}</span>
        </div>
      `).join('')
    : '<p class="hint">No sales logged in this range yet.</p>';

  const labels = data.monthly.map(m => m.month);
  const revenueData = data.monthly.map(m => m.revenue_cents / 100);
  const expenseData = data.monthly.map(m => m.expense_cents / 100);

  const ctx = document.getElementById('revenueChart');
  if (revenueChart) revenueChart.destroy();
  revenueChart = new Chart(ctx, {
    type: 'bar',
    data: {
      labels: labels.length ? labels : ['No data'],
      datasets: [
        { label: 'Revenue', data: revenueData.length ? revenueData : [0], backgroundColor: '#E8355F' },
        { label: 'Expenses', data: expenseData.length ? expenseData : [0], backgroundColor: '#3D1130' }
      ]
    },
    options: {
      responsive: true,
      plugins: { legend: { position: 'bottom' } },
      scales: { y: { ticks: { callback: v => '₹' + v } } }
    }
  });
}

document.getElementById('rangeApply').addEventListener('click', loadDashboard);
document.getElementById('rangeAllTime').addEventListener('click', () => {
  document.getElementById('rangeFrom').value = '';
  document.getElementById('rangeTo').value = '';
  loadDashboard();
});

// =========================================================
// SALES
// =========================================================
let menuProducts = []; // used to populate the item dropdowns and auto-fill price
let saleItemRowCount = 0;

function addSaleItemRow() {
  saleItemRowCount++;
  const rowId = `saleItem${saleItemRowCount}`;
  const wrapper = document.createElement('div');
  wrapper.className = 'sale-item-row';
  wrapper.id = rowId;
  wrapper.innerHTML = `
    <select class="item-product">
      <option value="">Custom item…</option>
      ${menuProducts.map(p => `<option value="${p.id}" data-price="${p.price_cents}">${p.name}</option>`).join('')}
    </select>
    <input type="text" class="item-name-custom" placeholder="Item name" style="flex:2; display:none;">
    <input type="number" class="item-qty" value="1" min="1" title="Quantity">
    <input type="number" class="item-price" step="1" min="0" placeholder="Price each (₹)" title="Price each">
    <button type="button" class="remove-item-btn" title="Remove">&times;</button>
  `;
  document.getElementById('saleItemsList').appendChild(wrapper);

  const select = wrapper.querySelector('.item-product');
  const customInput = wrapper.querySelector('.item-name-custom');
  const priceInput = wrapper.querySelector('.item-price');

  select.addEventListener('change', () => {
    if (select.value === '') {
      customInput.style.display = 'block';
      customInput.style.flex = '2';
      select.style.flex = '1';
    } else {
      customInput.style.display = 'none';
      select.style.flex = '2';
      const price = select.selectedOptions[0].dataset.price;
      priceInput.value = Math.round(price / 100);
    }
    updateSaleTotal();
  });

  wrapper.querySelector('.remove-item-btn').addEventListener('click', () => {
    wrapper.remove();
    updateSaleTotal();
  });
  wrapper.querySelectorAll('input').forEach(el => el.addEventListener('input', updateSaleTotal));
}

function updateSaleTotal() {
  let total = 0;
  document.querySelectorAll('.sale-item-row').forEach(row => {
    const qty = parseFloat(row.querySelector('.item-qty').value) || 0;
    const price = parseFloat(row.querySelector('.item-price').value) || 0;
    total += qty * price;
  });
  document.getElementById('saleFormTotal').textContent = `₹${Math.round(total).toLocaleString('en-IN')}`;
}

document.getElementById('addSaleItemBtn').addEventListener('click', addSaleItemRow);

document.getElementById('addSaleForm').addEventListener('submit', async (e) => {
  e.preventDefault();
  const form = e.target;
  const items = [];

  document.querySelectorAll('.sale-item-row').forEach(row => {
    const select = row.querySelector('.item-product');
    const customName = row.querySelector('.item-name-custom').value.trim();
    const name = select.value ? select.selectedOptions[0].textContent : customName;
    const qty = parseInt(row.querySelector('.item-qty').value, 10) || 0;
    const price = parseFloat(row.querySelector('.item-price').value) || 0;
    if (name && qty > 0) {
      items.push({ product_name: name, quantity: qty, price_cents_each: Math.round(price * 100) });
    }
  });

  if (items.length === 0) {
    alert('Add at least one item to this sale.');
    return;
  }

  const formData = new FormData(form);
  const payload = {
    customer_name: formData.get('customer_name'),
    phone: formData.get('phone'),
    sold_at: formData.get('sold_at') || todayStr(),
    notes: formData.get('notes'),
    items
  };

  const res = await fetch('/api/admin/sales', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload)
  });
  const data = await res.json();
  if (!res.ok) { alert(data.error || 'Could not log sale'); return; }

  form.reset();
  document.getElementById('saleItemsList').innerHTML = '';
  addSaleItemRow();
  updateSaleTotal();
  loadSales();
  loadDashboard();
});

async function loadSales() {
  const res = await fetch('/api/admin/sales');
  const sales = await res.json();
  const list = document.getElementById('salesList');

  if (sales.length === 0) {
    list.innerHTML = '<p class="hint">No sales logged yet.</p>';
    return;
  }

  list.innerHTML = sales.map(sale => {
    const total = sale.items.reduce((sum, i) => sum + i.quantity * i.price_cents_each, 0);
    const itemsText = sale.items.map(i => `${i.quantity}x ${i.product_name}`).join(', ');
    return `
      <div class="list-row">
        <div class="list-row-top">
          <div>
            <div class="list-row-title">${sale.customer_name}${sale.phone ? ' · ' + sale.phone : ''}</div>
            <div class="list-row-meta">${sale.sold_at}${sale.notes ? ' · ' + sale.notes : ''}</div>
          </div>
          <div style="display:flex; align-items:center; gap:10px;">
            <span class="list-row-amount">${formatPrice(total)}</span>
            <button class="delete-btn" data-id="${sale.id}" data-kind="sale">Delete</button>
          </div>
        </div>
        <div class="list-row-items">${itemsText}</div>
      </div>
    `;
  }).join('');

  attachDeleteHandlers();
}

// =========================================================
// EXPENSES
// =========================================================
document.getElementById('addExpenseForm').addEventListener('submit', async (e) => {
  e.preventDefault();
  const form = e.target;
  const formData = new FormData(form);

  const res = await fetch('/api/admin/expenses', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      item_name: formData.get('item_name'),
      category: formData.get('category'),
      amount: formData.get('amount'),
      purchased_at: formData.get('purchased_at') || todayStr(),
      notes: formData.get('notes')
    })
  });
  const data = await res.json();
  if (!res.ok) { alert(data.error || 'Could not log purchase'); return; }

  form.reset();
  loadExpenses();
  loadDashboard();
});

async function loadExpenses() {
  const res = await fetch('/api/admin/expenses');
  const expenses = await res.json();
  const list = document.getElementById('expensesList');

  if (expenses.length === 0) {
    list.innerHTML = '<p class="hint">No purchases logged yet.</p>';
    return;
  }

  list.innerHTML = expenses.map(exp => `
    <div class="list-row">
      <div class="list-row-top">
        <div>
          <div class="list-row-title">${exp.item_name}</div>
          <div class="list-row-meta">${exp.category} · ${exp.purchased_at}${exp.notes ? ' · ' + exp.notes : ''}</div>
        </div>
        <div style="display:flex; align-items:center; gap:10px;">
          <span class="list-row-amount">${formatPrice(exp.amount_cents)}</span>
          <button class="delete-btn" data-id="${exp.id}" data-kind="expense">Delete</button>
        </div>
      </div>
    </div>
  `).join('');

  attachDeleteHandlers();
}

function attachDeleteHandlers() {
  document.querySelectorAll('.delete-btn[data-kind]').forEach(btn => {
    btn.onclick = async () => {
      const kind = btn.dataset.kind;
      if (!confirm(`Delete this ${kind}?`)) return;
      const endpoint = kind === 'sale' ? `/api/admin/sales/${btn.dataset.id}` : `/api/admin/expenses/${btn.dataset.id}`;
      await fetch(endpoint, { method: 'DELETE' });
      if (kind === 'sale') loadSales(); else loadExpenses();
      loadDashboard();
    };
  });
}

// =========================================================
// MENU
// =========================================================
async function loadProducts() {
  const res = await fetch('/api/admin/products');
  const products = await res.json();
  menuProducts = products.filter(p => p.available);
  const list = document.getElementById('productsList');

  if (products.length === 0) {
    list.innerHTML = '<p>No menu items yet - add one above.</p>';
    return;
  }

  list.innerHTML = products.map(p => `
    <div class="product-row">
      <div class="product-row-left">
        ${p.image_url ? `<img class="product-thumb" src="${p.image_url}" alt="">` : `<div class="product-thumb-placeholder">${p.name.charAt(0)}</div>`}
        <div class="product-row-info">
          <div class="product-row-cat">${p.category}${p.is_signature ? ' · ⭐ Signature' : ''}</div>
          <strong>${p.name}</strong> — ${formatPrice(p.price_cents)}
          ${p.customization_note ? `<div class="product-row-custom">Customization: ${p.customization_note}</div>` : ''}
          ${p.variants && p.variants.length ? `<div class="product-row-variants">Options: ${p.variants.map(v => `${v.label} (${formatPrice(v.price_cents)})`).join(', ')}</div>` : ''}
        </div>
      </div>
      <div class="product-row-actions">
        <button class="availability-toggle" data-id="${p.id}" data-available="${p.available}">${p.available ? '✅ Visible' : '🚫 Hidden'}</button>
        <button class="delete-btn" data-id="${p.id}">Delete</button>
      </div>
    </div>
  `).join('');

  list.querySelectorAll('.availability-toggle').forEach(el => {
    el.addEventListener('click', async () => {
      const newAvailable = el.dataset.available === '1' ? 0 : 1;
      await fetch(`/api/admin/products/${el.dataset.id}`, {
        method: 'PATCH', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ available: newAvailable })
      });
      loadProducts();
    });
  });
  list.querySelectorAll('.product-row .delete-btn').forEach(el => {
    el.addEventListener('click', async () => {
      if (!confirm('Delete this item permanently?')) return;
      await fetch(`/api/admin/products/${el.dataset.id}`, { method: 'DELETE' });
      loadProducts();
    });
  });
}

// ---- Variant rows (weight/flavor combinations, each with its own price) ----
function addVariantRow() {
  const row = document.createElement('div');
  row.className = 'variant-row';
  row.innerHTML = `
    <input type="text" class="variant-label" placeholder="e.g. 500g">
    <input type="number" class="variant-price" placeholder="Price (₹)" min="0" step="1">
    <button type="button" class="variant-row-remove" title="Remove">&times;</button>
  `;
  document.getElementById('variantRows').appendChild(row);
  row.querySelector('.variant-row-remove').addEventListener('click', () => row.remove());
}
document.getElementById('addVariantRowBtn').addEventListener('click', addVariantRow);

function collectVariants() {
  const rows = document.querySelectorAll('#variantRows .variant-row');
  const variants = [];
  rows.forEach(row => {
    const label = row.querySelector('.variant-label').value.trim();
    const price = row.querySelector('.variant-price').value;
    if (label && price !== '') variants.push({ label, price });
  });
  return variants;
}

document.getElementById('addProductForm').addEventListener('submit', async (e) => {
  e.preventDefault();
  const form = e.target;
  const submitBtn = form.querySelector('button[type="submit"]');
  submitBtn.disabled = true;
  submitBtn.textContent = 'Adding…';
  const formData = new FormData(form);

  // is_signature comes through as "on" or absent from a checkbox - normalize to 1/0
  formData.set('is_signature', form.querySelector('[name="is_signature"]').checked ? '1' : '0');
  // variants are collected from the dynamic rows, not a plain form field
  formData.set('variants', JSON.stringify(collectVariants()));

  try {
    const res = await fetch('/api/admin/products', { method: 'POST', body: formData });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Could not add item');
    form.reset();
    document.getElementById('variantRows').innerHTML = '';
    loadProducts();
  } catch (err) {
    alert(err.message);
  } finally {
    submitBtn.disabled = false;
    submitBtn.textContent = 'Add Item';
  }
});

// =========================================================
// BRANDING (logo upload)
// =========================================================
async function loadBranding() {
  try {
    const res = await fetch('/api/config');
    const config = await res.json();
    const preview = document.getElementById('currentLogoPreview');
    if (config.logoUrl) {
      preview.innerHTML = `<img src="${config.logoUrl}" alt="Current logo">`;
    } else {
      preview.innerHTML = '<span class="logo-placeholder">No logo uploaded yet — showing "HT" placeholder on the site.</span>';
    }
  } catch (err) {
    // ignore - branding tab just stays on its default state
  }
}

document.getElementById('logoForm').addEventListener('submit', async (e) => {
  e.preventDefault();
  const form = e.target;
  const submitBtn = form.querySelector('button');
  const formData = new FormData(form);
  submitBtn.disabled = true;
  submitBtn.textContent = 'Uploading…';
  try {
    const res = await fetch('/api/admin/settings/logo', { method: 'POST', body: formData });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Could not upload logo');
    form.reset();
    loadBranding();
  } catch (err) {
    alert(err.message);
  } finally {
    submitBtn.disabled = false;
    submitBtn.textContent = 'Upload Logo';
  }
});

// =========================================================
// SITE CONTENT (address, story, testimonials, policy pages)
// =========================================================
async function loadContent() {
  try {
    const res = await fetch('/api/content');
    const content = await res.json();
    const form = document.getElementById('contentForm');
    Object.keys(content).forEach(key => {
      const field = form.elements[key];
      if (field) field.value = content[key] || '';
    });
  } catch (err) {
    // ignore - form just stays blank
  }
}

document.getElementById('contentForm').addEventListener('submit', async (e) => {
  e.preventDefault();
  const form = e.target;
  const status = document.getElementById('contentSaveStatus');
  const formData = new FormData(form);
  const payload = {};
  formData.forEach((value, key) => { payload[key] = value; });

  status.textContent = 'Saving…';
  try {
    const res = await fetch('/api/admin/content', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    });
    if (!res.ok) throw new Error('Could not save');
    status.textContent = 'Saved ✓';
    setTimeout(() => { status.textContent = ''; }, 2500);
  } catch (err) {
    status.textContent = 'Could not save — try again.';
  }
});

// =========================================================
// INIT
// =========================================================
async function init() {
  // Load products first so the sale-item dropdown can use them
  await loadProducts();
  addSaleItemRow();
  addVariantRow();
  loadDashboard();
  loadSales();
  loadExpenses();
  loadBranding();
  loadContent();
}
init();
