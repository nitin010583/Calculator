// Main entry point. Run it with: npm start
require('dotenv').config();
const express = require('express');
const basicAuth = require('express-basic-auth');
const multer = require('multer');
const path = require('path');
const fs = require('fs');
const db = require('./db/database');

const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

// ---------- Admin protection ----------
const adminAuth = basicAuth({
  users: { [process.env.ADMIN_USER || 'admin']: process.env.ADMIN_PASS || 'changeme123' },
  challenge: true,
  realm: 'Bakery Admin'
});

// ---------- Image upload setup ----------
const uploadDir = path.join(__dirname, 'public', 'images', 'products');
fs.mkdirSync(uploadDir, { recursive: true });

const brandDir = path.join(__dirname, 'public', 'images', 'branding');
fs.mkdirSync(brandDir, { recursive: true });

const brandStorage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, brandDir),
  filename: (req, file, cb) => {
    const ext = (file.originalname.match(/\.[a-zA-Z0-9]+$/) || [''])[0];
    cb(null, 'logo-' + Date.now() + ext.replace(/[^a-zA-Z0-9.]/g, ''));
  }
});
const uploadBrand = multer({
  storage: brandStorage,
  limits: { fileSize: 3 * 1024 * 1024 },
  fileFilter: (req, file, cb) => {
    const ok = /^image\/(jpeg|png|webp|svg\+xml)$/.test(file.mimetype);
    cb(ok ? null : new Error('Only image files are allowed (jpg, png, webp, svg).'), ok);
  }
});

const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, uploadDir),
  filename: (req, file, cb) => {
    const safeName = Date.now() + '-' + file.originalname.replace(/[^a-zA-Z0-9.\-_]/g, '');
    cb(null, safeName);
  }
});
const upload = multer({
  storage,
  limits: { fileSize: 5 * 1024 * 1024 },
  fileFilter: (req, file, cb) => {
    const ok = /^image\/(jpeg|png|webp|gif)$/.test(file.mimetype);
    cb(ok ? null : new Error('Only image files are allowed (jpg, png, webp, gif).'), ok);
  }
});

// Small helper: default a missing date-range to "all time"
function dateRange(req) {
  return {
    from: req.query.from || '0000-01-01',
    to: req.query.to || '9999-12-31'
  };
}

function getSetting(key, fallback = '') {
  const row = db.prepare('SELECT value FROM settings WHERE key = ?').get(key);
  return row ? row.value : fallback;
}
function setSetting(key, value) {
  db.prepare(`
    INSERT INTO settings (key, value) VALUES (?, ?)
    ON CONFLICT(key) DO UPDATE SET value = excluded.value
  `).run(key, value);
}

const getVariants = db.prepare('SELECT id, label, price_cents FROM product_variants WHERE product_id = ? ORDER BY sort_order, id');

// ============ PUBLIC (customer-facing) ============

app.get('/api/config', (req, res) => {
  res.json({
    whatsappNumber: process.env.WHATSAPP_NUMBER || '',
    logoUrl: getSetting('logo_url', '')
  });
});

app.get('/api/products', (req, res) => {
  const products = db
    .prepare('SELECT id, name, description, category, price_cents, image_url, customization_note, is_signature FROM products WHERE available = 1 ORDER BY category, id')
    .all();
  const withVariants = products.map(p => ({ ...p, variants: getVariants.all(p.id) }));
  res.json(withVariants);
});

// Editable site text (address, story, testimonials, policy pages) - all optional,
// falls back to empty string so the frontend can show its own placeholder note.
const CONTENT_KEYS = [
  'contact_address', 'contact_phone', 'story_text',
  'testimonial_1_quote', 'testimonial_1_name',
  'testimonial_2_quote', 'testimonial_2_name',
  'testimonial_3_quote', 'testimonial_3_name',
  'terms_text', 'privacy_text', 'shipping_text'
];

app.get('/api/content', (req, res) => {
  const content = {};
  CONTENT_KEYS.forEach(key => { content[key] = getSetting(key, ''); });
  res.json(content);
});

app.post('/api/admin/content', adminAuth, (req, res) => {
  CONTENT_KEYS.forEach(key => {
    if (req.body[key] !== undefined) setSetting(key, String(req.body[key]).slice(0, 4000));
  });
  res.json({ success: true });
});

// ============ ADMIN (password protected) ============

app.get('/admin', adminAuth, (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'admin.html'));
});

// ---- Menu management ----

app.get('/api/admin/products', adminAuth, (req, res) => {
  const products = db.prepare('SELECT * FROM products ORDER BY category, id').all();
  res.json(products.map(p => ({ ...p, variants: getVariants.all(p.id) })));
});

const insertVariant = db.prepare(`
  INSERT INTO product_variants (product_id, label, price_cents, sort_order) VALUES (?, ?, ?, ?)
`);
const deleteVariants = db.prepare('DELETE FROM product_variants WHERE product_id = ?');

// variants arrives as a JSON string in the form body, e.g. '[{"label":"500g","price":599},{"label":"1kg","price":999}]'
function saveVariants(productId, variantsRaw) {
  deleteVariants.run(productId);
  if (!variantsRaw) return;
  let list;
  try { list = JSON.parse(variantsRaw); } catch (e) { return; }
  if (!Array.isArray(list)) return;
  list.forEach((v, i) => {
    if (!v || !v.label || v.price === undefined || v.price === '') return;
    const price_cents = Math.round(parseFloat(v.price) * 100);
    if (isNaN(price_cents)) return;
    insertVariant.run(productId, String(v.label).slice(0, 60), price_cents, i);
  });
}

app.post('/api/admin/products', adminAuth, upload.single('image'), (req, res) => {
  const { name, description, category, price, customization_note, variants, is_signature } = req.body;
  if (!name || !price) return res.status(400).json({ error: 'name and price are required' });
  const price_cents = Math.round(parseFloat(price) * 100);
  const image_url = req.file ? `/images/products/${req.file.filename}` : '';

  const result = db.prepare(`
    INSERT INTO products (name, description, category, price_cents, image_url, customization_note, is_signature)
    VALUES (?, ?, ?, ?, ?, ?, ?)
  `).run(name, description || '', category || 'Other', price_cents, image_url, customization_note || '', is_signature ? 1 : 0);

  saveVariants(result.lastInsertRowid, variants);
  res.status(201).json({ id: result.lastInsertRowid });
});

app.patch('/api/admin/products/:id', adminAuth, (req, res) => {
  const existing = db.prepare('SELECT * FROM products WHERE id = ?').get(req.params.id);
  if (!existing) return res.status(404).json({ error: 'Product not found' });
  const merged = { ...existing, ...req.body };
  db.prepare(`
    UPDATE products SET name = ?, description = ?, category = ?, price_cents = ?, image_url = ?, available = ?, customization_note = ?, is_signature = ?
    WHERE id = ?
  `).run(
    merged.name, merged.description, merged.category, merged.price_cents, merged.image_url,
    merged.available ? 1 : 0, merged.customization_note || '', merged.is_signature ? 1 : 0, req.params.id
  );
  if (req.body.variants !== undefined) {
    saveVariants(req.params.id, req.body.variants);
  }
  res.json({ success: true });
});

app.delete('/api/admin/products/:id', adminAuth, (req, res) => {
  db.prepare('DELETE FROM products WHERE id = ?').run(req.params.id);
  res.json({ success: true });
});

// ---- Brand logo (site settings) ----

app.post('/api/admin/settings/logo', adminAuth, uploadBrand.single('logo'), (req, res) => {
  if (!req.file) return res.status(400).json({ error: 'No logo file received' });
  const logo_url = `/images/branding/${req.file.filename}`;
  setSetting('logo_url', logo_url);
  res.status(201).json({ logo_url });
});

// ---- Sales (log a completed deal - who ordered, what, and the final price) ----

app.get('/api/admin/sales', adminAuth, (req, res) => {
  const { from, to } = dateRange(req);
  const sales = db.prepare(`
    SELECT * FROM sales WHERE sold_at BETWEEN ? AND ? ORDER BY sold_at DESC, id DESC
  `).all(from, to);
  const getItems = db.prepare('SELECT * FROM sale_items WHERE sale_id = ?');
  res.json(sales.map(sale => ({ ...sale, items: getItems.all(sale.id) })));
});

// POST body: { customer_name, phone, sold_at, notes, items: [{ product_name, quantity, price_cents_each }] }
app.post('/api/admin/sales', adminAuth, (req, res) => {
  const { customer_name, phone, sold_at, notes, items } = req.body;
  if (!customer_name || !Array.isArray(items) || items.length === 0) {
    return res.status(400).json({ error: 'customer_name and at least one item are required' });
  }

  const insertSale = db.prepare(`
    INSERT INTO sales (customer_name, phone, sold_at, notes) VALUES (?, ?, COALESCE(?, date('now')), ?)
  `);
  const insertItem = db.prepare(`
    INSERT INTO sale_items (sale_id, product_name, quantity, price_cents_each) VALUES (?, ?, ?, ?)
  `);

  const placeSale = db.transaction(() => {
    const result = insertSale.run(customer_name, phone || null, sold_at || null, notes || null);
    const saleId = result.lastInsertRowid;
    for (const item of items) {
      const qty = Math.max(1, parseInt(item.quantity, 10) || 1);
      const priceCents = Math.round(parseFloat(item.price_cents_each) || 0);
      insertItem.run(saleId, item.product_name, qty, priceCents);
    }
    return saleId;
  });

  const saleId = placeSale();
  res.status(201).json({ id: saleId });
});

app.delete('/api/admin/sales/:id', adminAuth, (req, res) => {
  db.prepare('DELETE FROM sales WHERE id = ?').run(req.params.id);
  res.json({ success: true });
});

// ---- Expenses (raw material / supply purchases) ----

app.get('/api/admin/expenses', adminAuth, (req, res) => {
  const { from, to } = dateRange(req);
  const expenses = db.prepare(`
    SELECT * FROM expenses WHERE purchased_at BETWEEN ? AND ? ORDER BY purchased_at DESC, id DESC
  `).all(from, to);
  res.json(expenses);
});

app.post('/api/admin/expenses', adminAuth, (req, res) => {
  const { item_name, category, amount, purchased_at, notes } = req.body;
  if (!item_name || !amount) return res.status(400).json({ error: 'item_name and amount are required' });
  const amount_cents = Math.round(parseFloat(amount) * 100);

  const result = db.prepare(`
    INSERT INTO expenses (item_name, category, amount_cents, purchased_at, notes)
    VALUES (?, ?, ?, COALESCE(?, date('now')), ?)
  `).run(item_name, category || 'Other', amount_cents, purchased_at || null, notes || null);

  res.status(201).json({ id: result.lastInsertRowid });
});

app.delete('/api/admin/expenses/:id', adminAuth, (req, res) => {
  db.prepare('DELETE FROM expenses WHERE id = ?').run(req.params.id);
  res.json({ success: true });
});

// ---- Dashboard (profit & loss) ----

app.get('/api/admin/dashboard', adminAuth, (req, res) => {
  const { from, to } = dateRange(req);

  const revenueRow = db.prepare(`
    SELECT COALESCE(SUM(si.quantity * si.price_cents_each), 0) AS revenue_cents,
           COUNT(DISTINCT s.id) AS sale_count
    FROM sales s JOIN sale_items si ON si.sale_id = s.id
    WHERE s.sold_at BETWEEN ? AND ?
  `).get(from, to);

  const expenseRow = db.prepare(`
    SELECT COALESCE(SUM(amount_cents), 0) AS expense_cents
    FROM expenses WHERE purchased_at BETWEEN ? AND ?
  `).get(from, to);

  const topItems = db.prepare(`
    SELECT si.product_name,
           SUM(si.quantity) AS total_qty,
           SUM(si.quantity * si.price_cents_each) AS total_revenue_cents
    FROM sale_items si JOIN sales s ON s.id = si.sale_id
    WHERE s.sold_at BETWEEN ? AND ?
    GROUP BY si.product_name
    ORDER BY total_revenue_cents DESC
    LIMIT 5
  `).all(from, to);

  const monthlyRevenue = db.prepare(`
    SELECT strftime('%Y-%m', s.sold_at) AS month, SUM(si.quantity * si.price_cents_each) AS revenue_cents
    FROM sales s JOIN sale_items si ON si.sale_id = s.id
    WHERE s.sold_at BETWEEN ? AND ?
    GROUP BY month ORDER BY month
  `).all(from, to);

  const monthlyExpenses = db.prepare(`
    SELECT strftime('%Y-%m', purchased_at) AS month, SUM(amount_cents) AS expense_cents
    FROM expenses WHERE purchased_at BETWEEN ? AND ?
    GROUP BY month ORDER BY month
  `).all(from, to);

  // Merge revenue + expenses into one array per month for easy charting
  const monthsSet = new Set([...monthlyRevenue.map(r => r.month), ...monthlyExpenses.map(e => e.month)]);
  const months = [...monthsSet].sort();
  const monthly = months.map(month => ({
    month,
    revenue_cents: monthlyRevenue.find(r => r.month === month)?.revenue_cents || 0,
    expense_cents: monthlyExpenses.find(e => e.month === month)?.expense_cents || 0
  }));

  res.json({
    revenue_cents: revenueRow.revenue_cents,
    expense_cents: expenseRow.expense_cents,
    profit_cents: revenueRow.revenue_cents - expenseRow.expense_cents,
    sale_count: revenueRow.sale_count,
    top_items: topItems,
    monthly
  });
});

// Multer errors (e.g. file too big, wrong type) land here instead of crashing the server
app.use((err, req, res, next) => {
  if (err) return res.status(400).json({ error: err.message });
  next();
});

app.listen(PORT, () => {
  console.log(`\n🥐 Bakery server running!`);
  console.log(`   Menu:  http://localhost:${PORT}`);
  console.log(`   Admin: http://localhost:${PORT}/admin\n`);
});
