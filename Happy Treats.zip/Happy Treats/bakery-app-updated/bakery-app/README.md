# Happy Treats — Home Bakery Site

A catalog site: customers browse your menu by category, build an order, then
tap a button to send it to you as a pre-filled WhatsApp message. No payments
or order storage happen on the site itself.

## What's inside
- `server.js` — the web server (Express)
- `db/database.js` — creates your SQL `products` table
- `db/seed.js` — adds sample menu items
- `public/` — everything the customer sees (HTML/CSS/JS)
- `public/admin.html` + `admin.js` — password-protected menu management (add items, upload photos, set categories, hide/delete items)

## 1. Install Node.js
Download from https://nodejs.org (LTS version). Confirm with:
```
node -v
npm -v
```

## 2. Install project dependencies
Inside this folder:
```
npm install
```

## 3. Configure your settings
Copy `.env.example` to `.env`:
```
cp .env.example .env
```
Open `.env` and set:
- `ADMIN_USER` / `ADMIN_PASS` — your own admin login
- `WHATSAPP_NUMBER` — your number in international format, digits only, no `+`.
  Example: `+1 (555) 123-4567` → `15551234567`

## 4. Create the database and add sample products
```
npm run seed
```
Creates `db/bakery.sqlite` with 4 sample items across different categories.

## 5. Start the server
```
npm start
```
```
🥐 Bakery server running!
   Menu:  http://localhost:3000
   Admin: http://localhost:3000/admin
```

## 6. Try it
- **Menu:** http://localhost:3000 — add a couple items to the cart, click "Order on WhatsApp", and confirm it opens WhatsApp Web/app with your items pre-filled.
- **Admin:** http://localhost:3000/admin — log in with the credentials from `.env`. Add an item with a photo and a category, then refresh the menu page to see it appear.

## Editing the menu
- **Admin panel** (easiest): add items with name, category, price, description, and a photo upload. Toggle visibility or delete items from the list.
- **Direct SQL** (since you know it):
  ```
  npx sqlite3 db/bakery.sqlite
  ```
  ```sql
  SELECT * FROM products;
  UPDATE products SET price_cents = 900 WHERE name = 'Sourdough Loaf';
  .quit
  ```

## Notes
- Uploaded photos are saved to `public/images/products/` and referenced by the database.
- If you'd previously run an older version of this project, delete the old `db/bakery.sqlite` file before running `npm run seed` again, since the table structure changed.

## The Admin panel now has 4 tabs

**Dashboard** — revenue, expenses, and profit for a date range (or all time), a bar chart by month, and your best-selling items.

**Sales** — log a completed deal once you've agreed it with a customer (e.g. over WhatsApp): customer name, phone, date, one or more items with quantity and the *actual* price you charged (it doesn't have to match the menu price — use this for discounts or custom quotes). This is also your record of "who ordered what."

**Expenses** — log raw material / supply purchases: item, category (e.g. Ingredients, Packaging), amount, date. These get subtracted from revenue to calculate profit.

**Menu** — unchanged: add items with photos and categories for the public site.

All of this data lives in the same `db/bakery.sqlite` file, in three tables: `products`, `sales` (+ `sale_items`), and `expenses`. You can always query it directly:
```sql
SELECT * FROM sales;
SELECT * FROM expenses;
SELECT SUM(quantity * price_cents_each) FROM sale_items;  -- total revenue, in cents
```

## Next steps (when you're ready)
- Replace sample items with your real menu, categories, and photos
- Update the site name/hero text in `index.html`
- Start logging real sales and expenses so the dashboard has real numbers
- Deploy publicly (free hosting that supports Node + file uploads, e.g. Render or Railway) and point a domain at it — I'll walk you through this when you're ready.
