// Run this once with: npm run seed
// Adds a few starter products so your menu isn't empty and you can see
// how categories work. Safe to re-run - it only inserts if products is empty.
// Feel free to delete these later from the Admin panel once you add your own.

const db = require('./database');

const count = db.prepare('SELECT COUNT(*) AS n FROM products').get().n;

if (count > 0) {
  console.log(`Products table already has ${count} item(s). Skipping seed.`);
  process.exit(0);
}

const insert = db.prepare(`
  INSERT INTO products (name, description, category, price_cents, image_url, available)
  VALUES (@name, @description, @category, @price_cents, @image_url, 1)
`);

const sampleProducts = [
  { name: 'Sourdough Loaf', description: 'Naturally leavened, 24-hour fermented, crisp crust.', category: 'Breads', price_cents: 800, image_url: '' },
  { name: 'Chocolate Chip Cookies (dozen)', description: 'Brown-butter dough, sea salt finish.', category: 'Cookies', price_cents: 1200, image_url: '' },
  { name: 'Cinnamon Rolls (6-pack)', description: 'Soft brioche, cream cheese glaze.', category: 'Pastries', price_cents: 1500, image_url: '' },
  { name: 'Lemon Cake', description: 'Whole cake, 8 inch, lemon curd filling.', category: 'Cakes', price_cents: 2800, image_url: '' }
];

const insertMany = db.transaction((items) => { for (const item of items) insert.run(item); });
insertMany(sampleProducts);
console.log(`Inserted ${sampleProducts.length} sample products.`);
