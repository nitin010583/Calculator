// This file sets up our SQL database.
// SQLite stores the whole database as ONE FILE on disk (db/bakery.sqlite).

const Database = require('better-sqlite3');
const path = require('path');

const db = new Database(path.join(__dirname, 'bakery.sqlite'));
db.pragma('foreign_keys = ON');

db.exec(`
  -- Your public menu. Customers browse this; it drives the WhatsApp cart.
  CREATE TABLE IF NOT EXISTS products (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    name        TEXT NOT NULL,
    description TEXT,
    category    TEXT NOT NULL DEFAULT 'Other',
    price_cents INTEGER NOT NULL,
    image_url   TEXT,
    available   INTEGER NOT NULL DEFAULT 1,
    customization_note TEXT  -- e.g. "Extra tier +₹500, photo print +₹200" - shown to customers so they know customization costs extra
  );

  -- A sale you log yourself once a WhatsApp deal is final. The price here
  -- is whatever you actually charged - it does NOT have to match the
  -- product's listed price (e.g. if you gave a discount or custom quote).
  CREATE TABLE IF NOT EXISTS sales (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    customer_name TEXT NOT NULL,
    phone         TEXT,
    sold_at       TEXT NOT NULL DEFAULT (date('now')),  -- the date of the sale (YYYY-MM-DD)
    notes         TEXT,
    created_at    TEXT NOT NULL DEFAULT (datetime('now'))
  );

  CREATE TABLE IF NOT EXISTS sale_items (
    id               INTEGER PRIMARY KEY AUTOINCREMENT,
    sale_id          INTEGER NOT NULL REFERENCES sales(id) ON DELETE CASCADE,
    product_name     TEXT NOT NULL,   -- text, not a foreign key, so you can log items even if deleted from the menu
    quantity         INTEGER NOT NULL,
    price_cents_each INTEGER NOT NULL  -- the ACTUAL price charged for this sale
  );

  -- Raw material / supply purchases (flour, sugar, boxes, gas, etc.)
  CREATE TABLE IF NOT EXISTS expenses (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    item_name    TEXT NOT NULL,
    category     TEXT NOT NULL DEFAULT 'Other',
    amount_cents INTEGER NOT NULL,
    purchased_at TEXT NOT NULL DEFAULT (date('now')),
    notes        TEXT,
    created_at   TEXT NOT NULL DEFAULT (datetime('now'))
  );
`);

// Migration: if this database already existed before customization_note was added,
// ALTER it in. Safe to run every startup - it just no-ops once the column exists.
try {
  db.exec(`ALTER TABLE products ADD COLUMN customization_note TEXT`);
} catch (e) {
  // Column already exists - ignore
}

module.exports = db;
